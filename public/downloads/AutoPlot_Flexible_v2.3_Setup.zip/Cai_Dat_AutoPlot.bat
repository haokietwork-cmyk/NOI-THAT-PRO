@echo off
title Cai dat va Cap nhat AutoPlot Flexible v2.3 cho AutoCAD
cls

echo ======================================================================
echo           AUTOPLOT FLEXIBLE v2.3 - CAI DAT VA NANG CAP TU DONG
echo      Dong co xem truoc: NATIVE CANVAS (Khong mo Web / Coc Coc)
echo      Tuong thich: AutoCAD 2014, 2015, 2016, 2017, 2018-2027 (Universal)
echo ======================================================================
echo.

:: 1. KIEM TRA THU MUC NGUON
set "SOURCE_DIR=%~dp0AutoPlotFlexible.bundle"
if not exist "%SOURCE_DIR%" goto :ERR_NO_SOURCE

:: 2. DONG TIEN TRINH AUTOCAD DE MO KHOA FILE DLL
echo [1/4] Dang kiem tra tien trinh AutoCAD...
tasklist /fi "imagename eq acad.exe" 2>nul | find /i "acad.exe" >nul
if errorlevel 1 goto :ACAD_CLOSED

echo       Phat hien AutoCAD dang mo. Dang tu dong dong de giai phong file...
taskkill /f /im acad.exe >nul 2>&1
taskkill /f /im acadlt.exe >nul 2>&1
taskkill /f /im accoreconsole.exe >nul 2>&1
ping 127.0.0.1 -n 3 >nul

:ACAD_CLOSED
echo       AutoCAD da san sang.

:: 3. SAO LUU GIAY PHEP BAN QUYEN HIEN CO
set "TARGET_USER=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
set "TARGET_ALL=%ProgramData%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
set "TEMP_LIC=%TEMP%\AutoPlot_Flexible_License_Backup.lic"

echo [2/4] Dang kiem tra va giu lai ban quyen da kich hoat...
if exist "%TARGET_USER%\FlexibleTools.lic" (
    copy /y "%TARGET_USER%\FlexibleTools.lic" "%TEMP_LIC%" >nul 2>&1
    echo       Da tim thay giay phep ban quyen hien tai. Se tu dong khoi phuc.
)

:: 4. XOA BAN CU VA CAI DAT BAN MOI v2.3
echo [3/4] Dang go bo phien ban cu va cai dat v2.3 moi nhat...
if exist "%TARGET_USER%" rmdir /s /q "%TARGET_USER%" 2>nul
if exist "%TARGET_ALL%" rmdir /s /q "%TARGET_ALL%" 2>nul
if exist "%APPDATA%\Autodesk\ApplicationPlugins\APMP.bundle" rmdir /s /q "%APPDATA%\Autodesk\ApplicationPlugins\APMP.bundle" 2>nul
if exist "%ProgramData%\Autodesk\ApplicationPlugins\APMP.bundle" rmdir /s /q "%ProgramData%\Autodesk\ApplicationPlugins\APMP.bundle" 2>nul

if not exist "%APPDATA%\Autodesk\ApplicationPlugins" (
    mkdir "%APPDATA%\Autodesk\ApplicationPlugins" 2>nul
)

xcopy "%SOURCE_DIR%" "%TARGET_USER%\" /s /e /i /y /q >nul
if errorlevel 1 goto :ERR_COPY

:: Tuy chon copy vao ProgramData neu co quyen Admin
xcopy "%SOURCE_DIR%" "%TARGET_ALL%\" /s /e /i /y /q >nul 2>&1

:: Khoi phuc ban quyen neu co
if exist "%TEMP_LIC%" (
    copy /y "%TEMP_LIC%" "%TARGET_USER%\FlexibleTools.lic" >nul 2>&1
    copy /y "%TEMP_LIC%" "%TARGET_ALL%\FlexibleTools.lic" >nul 2>&1
    del "%TEMP_LIC%" >nul 2>&1
    echo       Da tu dong bao toan giay phep ban quyen thanh cong!
)

:: 5. MO KHOA UNBLOCK VA KIEM TRA PHIEN BAN
echo [4/4] Dang mo khoa thu vien (Unblock) va kiem tra cai dat...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%TARGET_USER%' -Recurse | Unblock-File" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%TARGET_ALL%' -Recurse | Unblock-File" >nul 2>&1

if not exist "%TARGET_USER%\Contents\AutoPlotFlexible.dll" goto :ERR_VERIFY

echo.
echo ======================================================================
echo                  CAI DAT v2.3 HOAN TAT THANH CONG!
echo ======================================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$v = (Get-Item '%TARGET_USER%\Contents\AutoPlotFlexible.dll').VersionInfo.FileVersion; Write-Host ('   [OK] Da nap thanh cong phien ban: AutoPlot Flexible v' + $v) -ForegroundColor Green"
echo.
echo   - Dong co xem truoc: Native Canvas (Khong mo Web / Coc Coc).
echo   - Tu dong nap khi mo AutoCAD (AutoCAD 2014, 2015, 2016 ... 2027).
echo   - Da loai bo hoan toan lenh IN trung lap voi cong cu khac.
echo.
echo HUONG DAN SU DUNG:
echo   1. Mo phan mem AutoCAD (hoac AutoCAD Mechanical 2014-2027).
echo   2. Go lenh: AUTOPLOT.
echo   3. Bam 'Quet tat ca' va bam 'IN GOP PDF'.
echo ======================================================================
echo.
echo Bam phim bat ky de dong cua so cai dat...
pause >nul
exit /b 0

:ERR_NO_SOURCE
echo [LOI] Khong tim thay thu muc AutoPlotFlexible.bundle!
echo Vui long giai nen toan bo file 'AutoPlot_Flexible_v2.3_Setup.zip' truoc khi chay.
pause
exit /b 1

:ERR_COPY
echo [LOI] Sao chep vao AppData that bai!
echo Vui long kiem tra quyen truy cap hoac khoi dong lai may.
pause
exit /b 1

:ERR_VERIFY
echo [LOI] Khong tim thay file AutoPlotFlexible.dll sau khi cai dat!
pause
exit /b 1

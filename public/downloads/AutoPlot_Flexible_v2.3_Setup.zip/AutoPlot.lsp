;;; =========================================================================
;;; AUTOPLOT FLEXIBLE v2.3 - BỘ NẠP ĐA PHIÊN BẢN CHO TẤT CẢ AUTOCAD (2014-2027)
;;; Tương thích: AutoCAD 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027
;;; Động cơ xem trước: Native Canvas Engine (Khắc phục triệt để lỗi mở Web/Cốc Cốc)
;;; =========================================================================

(vl-load-com)

(defun c:AUTOPLOT ()
  (setq lsp-file (findfile "AutoPlot.lsp"))
  (setq cur-dir (if lsp-file (vl-filename-directory lsp-file) nil))
  
  (setq appdata-bundle (strcat (getenv "APPDATA") "\\Autodesk\\ApplicationPlugins\\AutoPlotFlexible.bundle\\Contents\\AutoPlotFlexible.dll"))
  (setq progdata-bundle (strcat (getenv "ProgramData") "\\Autodesk\\ApplicationPlugins\\AutoPlotFlexible.bundle\\Contents\\AutoPlotFlexible.dll"))
  (setq bundle-in-curdir (if cur-dir (strcat cur-dir "\\AutoPlotFlexible.bundle\\Contents\\AutoPlotFlexible.dll") nil))
  
  (setq dll-candidates (list
    bundle-in-curdir
    appdata-bundle
    progdata-bundle
    (if cur-dir (strcat cur-dir "/AutoPlotFlexible.dll") nil)
    (if cur-dir (strcat cur-dir "/AutoPlotFlexible_Universal.dll") nil)
    (if cur-dir (strcat cur-dir "/Contents/AutoPlotFlexible.dll") nil)
    (if cur-dir (strcat cur-dir "/bin/AutoPlotFlexible.dll") nil)
  ))
  
  (setq target-dll nil)
  (foreach cand dll-candidates
    (if (and (null target-dll) cand (findfile cand))
      (setq target-dll (findfile cand))
    )
  )
  
  (if target-dll
    (progn
      (vl-cmdf "NETLOAD" target-dll)
      (setq doc (vla-get-activedocument (vlax-get-acad-object)))
      (vla-sendcommand doc "AUTOPLOT\n")
      (princ (strcat "\n[AutoPlot Flexible v2.3] Da nap thanh cong: " target-dll))
    )
    (alert "Khong tim thay tap tin AutoPlotFlexible.dll!\nVui long chay file 'Cai_Dat_AutoPlot.bat' hoac dat AutoPlot.lsp cung thu muc voi AutoPlotFlexible.bundle.")
  )
  (princ)
)

(princ "\n[AutoPlot Flexible v2.3] Da san sang! Go 'AUTOPLOT' de bat dau.\n")
(princ)

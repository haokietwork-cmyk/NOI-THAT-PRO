@echo off
chcp 65001 >nul
echo ======================================================================
echo           AUTOPLOT FLEXIBLE v2.2 - CAI DAT TU DONG CHO AUTOCAD
echo      In an hang loat - Chuan ti le X:1 - Nhan dien Ten & So hieu BV
echo      Tuong thich: AutoCAD 2014, 2015, 2016, 2017, 2018-2026+ (Universal)
echo ======================================================================
echo.

set "TARGET_DIR=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
set "SOURCE_DIR=%~dp0AutoPlotFlexible.bundle"

if not exist "%SOURCE_DIR%" (
    echo [LOI] Khong tim thay thu muc AutoPlotFlexible.bundle cung thu muc voi file cai dat!
    echo Vui long giai nen toan bo file zip truoc khi chay.
    echo.
    pause
    exit /b 1
)

echo [1/3] Dang tao thu muc dich trong Autodesk ApplicationPlugins...
if not exist "%APPDATA%\Autodesk\ApplicationPlugins" (
    mkdir "%APPDATA%\Autodesk\ApplicationPlugins"
)

echo [2/3] Dang sao chep AutoPlot Flexible v2.2 vao he thong...
xcopy "%SOURCE_DIR%" "%TARGET_DIR%\" /s /e /i /y /q >nul
if errorlevel 1 (
    echo [LOI] Sao chep that bai! Vui long dong AutoCAD neu dang mo va thu lai.
    echo.
    pause
    exit /b 1
)

echo [3/3] Dang mo khoa (Unblock) thu vien de Windows khong chan DLL...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%TARGET_DIR%' -Recurse | Unblock-File" >nul 2>&1

echo.
echo ======================================================================
echo                      CAI DAT HOAN TAT THANH CONG!
echo ======================================================================
echo.
echo Cong cu da duoc tich hop vinh vien vao he thong AutoCAD cua ban:
echo   - Tu dong nap khi khoi dong AutoCAD (AutoCAD 2014 - 2026+).
echo   - Neu AutoCAD doi cu (2014-2017) chua bat Bundle, ban chi can keo tha
echo     file 'AutoPlot.lsp' vao ban ve AutoCAD hoac go lenh APPLOAD.
echo.
echo HUONG DAN SU DUNG NHANH:
echo   1. Mo phan mem AutoCAD.
echo   2. Go lenh: AUTOPLOT (hoac phim tat: AP).
echo   3. Bam 'Quet tat ca' de tu dong nhan dien toan bo khung ban ve,
echo      tu dong trich xuat Ten ban ve, So hieu va Ti le phong to X:1.
echo   4. Bam 'IN & GOP PDF' de xuat 1 file PDF duy nhat co Bookmark!
echo.
echo ======================================================================
echo Bam phim bat ky de dong cua so nay...
pause >nul

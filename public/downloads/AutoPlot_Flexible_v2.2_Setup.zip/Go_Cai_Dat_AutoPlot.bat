@echo off
chcp 65001 >nul
title Gỡ cài đặt AutoPlot Flexible cho Autodesk AutoCAD
cls
echo ======================================================================
echo                GỠ CÀI ĐẶT AUTOPLOT FLEXIBLE KHỎI AUTOCAD
echo ======================================================================
echo.

set "TARGET_DIR=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"

if not exist "%TARGET_DIR%" (
    echo [THÔNG BÁO] AutoPlot Flexible hiện không được cài đặt trong thư mục:
    echo %TARGET_DIR%
    echo.
    pause
    exit /b 0
)

echo Bạn có chắc chắn muốn gỡ cài đặt AutoPlot Flexible khỏi hệ thống?
set /p "CHOICE=Nhập Y để đồng ý gỡ, hoặc phím bất kỳ để hủy [Y/N]: "
if /i not "%CHOICE%"=="Y" (
    echo.
    echo Đã hủy thao tác gỡ cài đặt.
    pause
    exit /b 0
)

echo.
tasklist /fi "imagename eq acad.exe" 2>nul | find /i "acad.exe" >nul
if not errorlevel 1 (
    echo [CẢNH BÁO] AutoCAD đang chạy! Vui lòng đóng AutoCAD để không bị khóa file.
    set /p "CLOSE_ACAD=Bạn có muốn đóng AutoCAD ngay bây giờ không? [Y/N]: "
    if /i "%CLOSE_ACAD%"=="Y" (
        taskkill /f /im acad.exe >nul 2>&1
        timeout /t 2 /nobreak >nul
    ) else (
        echo Vui lòng đóng AutoCAD rồi chạy lại file này.
        pause
        exit /b 1
    )
)

echo Đang gỡ bỏ AutoPlot Flexible khỏi hệ thống...
rmdir /s /q "%TARGET_DIR%" 2>nul
if exist "%TARGET_DIR%" (
    echo [LỖI] Không thể xóa toàn bộ tệp! Vui lòng kiểm tra lại quyền Administrator.
    echo.
    pause
    exit /b 1
)

echo.
echo ======================================================================
echo                      GỠ CÀI ĐẶT HOÀN TẤT!
echo AutoPlot Flexible đã được gỡ bỏ sạch sẽ khỏi hệ thống AutoCAD của bạn.
echo ======================================================================
echo.
pause

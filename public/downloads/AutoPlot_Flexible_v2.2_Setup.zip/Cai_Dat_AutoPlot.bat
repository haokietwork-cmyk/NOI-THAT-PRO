@echo off
chcp 65001 >nul
title Cài đặt & Cập nhật AutoPlot Flexible v2.2 cho AutoCAD
cls
echo ======================================================================
echo           AUTOPLOT FLEXIBLE v2.2 - CÀI ĐẶT & NÂNG CẤP TỰ ĐỘNG
echo      In ấn hàng loạt - Chuẩn tỉ lệ X:1 - Nhận diện Tên & Số hiệu BV
echo      Tương thích: AutoCAD 2014, 2015, 2016, 2017, 2018-2027 (Universal)
echo ======================================================================
echo.

set "TARGET_DIR=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
set "SOURCE_DIR=%~dp0AutoPlotFlexible.bundle"

if not exist "%SOURCE_DIR%" (
    echo [LỖI] Không tìm thấy thư mục AutoPlotFlexible.bundle cùng thư mục với file cài đặt!
    echo Vui lòng giải nén toàn bộ file zip trước khi chạy file cài đặt này.
    echo.
    pause
    exit /b 1
)

:: BƯỚC 1: KIỂM TRA AUTOCAD ĐANG CHẠY (BẮT BUỘC ĐÓNG ĐỂ KHÔNG BỊ KHÓA DLL CŨ)
echo [1/4] Đang kiểm tra tiến trình AutoCAD...
tasklist /fi "imagename eq acad.exe" 2>nul | find /i "acad.exe" >nul
if not errorlevel 1 (
    echo.
    echo [CẢNH BÁO] AutoCAD đang mở trên máy tính của bạn!
    echo Để gỡ bỏ phiên bản cũ sạch sẽ và cập nhật bản mới, AutoCAD cần được đóng.
    echo.
    set /p "CLOSE_ACAD=Bạn có muốn đóng AutoCAD ngay bây giờ không? (Lưu bản vẽ trước) [Y/N]: "
    if /i "%CLOSE_ACAD%"=="Y" (
        echo Đang đóng AutoCAD...
        taskkill /f /im acad.exe >nul 2>&1
        timeout /t 2 /nobreak >nul
    ) else (
        echo.
        echo Vui lòng lưu bản vẽ và đóng AutoCAD, sau đó chạy lại file cài đặt này.
        echo.
        pause
        exit /b 1
    )
)

:: BƯỚC 2: SAO LƯU GIẤY PHÉP BẢN QUYỀN NẾU ĐÃ KÍCH HOẠT VÀ DỌN SẠCH TOÀN BỘ BẢN CŨ
echo [2/4] Đang dọn dẹp sạch sẽ toàn bộ phiên bản cũ khỏi hệ thống...
set "TEMP_LIC=%TEMP%\FlexibleTools_preserve_%RANDOM%.lic"
if exist "%TARGET_DIR%\FlexibleTools.lic" (
    copy /y "%TARGET_DIR%\FlexibleTools.lic" "%TEMP_LIC%" >nul 2>&1
)

if exist "%TARGET_DIR%" (
    rmdir /s /q "%TARGET_DIR%" 2>nul
)

if not exist "%APPDATA%\Autodesk\ApplicationPlugins" (
    mkdir "%APPDATA%\Autodesk\ApplicationPlugins"
)

:: BƯỚC 3: SAO CHÉP PHIÊN BẢN MỚI NHẤT
echo [3/4] Đang cài đặt AutoPlot Flexible v2.2 mới nhất vào hệ thống...
xcopy "%SOURCE_DIR%" "%TARGET_DIR%\" /s /e /i /y /q >nul
if errorlevel 1 (
    echo [LỖI] Sao chép tệp thất bại! Vui lòng khởi động lại máy hoặc tắt phần mềm diệt virus rồi thử lại.
    echo.
    pause
    exit /b 1
)

:: Khôi phục bản quyền của máy cũ nếu có
if exist "%TEMP_LIC%" (
    copy /y "%TEMP_LIC%" "%TARGET_DIR%\FlexibleTools.lic" >nul 2>&1
    del "%TEMP_LIC%" >nul 2>&1
    echo [THÔNG TIN] Đã tự động giữ lại giấy phép bản quyền của bạn!
)

:: BƯỚC 4: MỞ KHÓA DLL (UNBLOCK)
echo [4/4] Đang mở khóa (Unblock) thư viện để Windows không chặn DLL...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%TARGET_DIR%' -Recurse | Unblock-File" >nul 2>&1

echo.
echo ======================================================================
echo                  CÀI ĐẶT & CẬP NHẬT HOÀN TẤT THÀNH CÔNG!
echo ======================================================================
echo.
echo   - Toàn bộ phiên bản cũ đã được gỡ bỏ sạch sẽ khỏi hệ thống.
echo   - Bản quyền đã kích hoạt (nếu có) được tự động bảo toàn 100%.
echo   - Thư viện gộp PDF và tối ưu chống mở tab trình duyệt đã nạp đầy đủ.
echo   - Phiên bản mới AutoPlot Flexible v2.2 đã sẵn sàng hoạt động.
echo   - Tự động nạp khi khởi động AutoCAD (AutoCAD 2014 - 2027).
echo.
echo HƯỚNG DẪN SỬ DỤNG:
echo   1. Mở phần mềm AutoCAD.
echo   2. Gõ lệnh: AUTOPLOT (hoặc phím tắt: AP).
echo   3. Bấm 'Quét tất cả' để tự động nhận diện khung bản vẽ.
echo   4. Bấm 'IN & GỘP PDF' để xuất file PDF duy nhất có mục lục Bookmark!
echo.
echo ======================================================================
echo Bấm phím bất kỳ để đóng cửa sổ này...
pause >nul

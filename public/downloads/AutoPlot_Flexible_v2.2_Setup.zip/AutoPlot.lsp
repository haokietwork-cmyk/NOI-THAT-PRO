;;; =========================================================================
;;; AUTOPLOT FLEXIBLE v2.2 - BỘ NẠP ĐA PHIÊN BẢN CHO TẤT CẢ AUTOCAD (2014-2026+)
;;; Tương thích: AutoCAD 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026+
;;; =========================================================================

(vl-load-com)

(defun c:AUTOPLOT ()
  (setq lsp-file (findfile "AutoPlot.lsp"))
  (setq cur-dir (if lsp-file (vl-filename-directory lsp-file) nil))
  
  (setq appdata-bundle (strcat (getenv "APPDATA") "\\Autodesk\\ApplicationPlugins\\AutoPlotFlexible.bundle\\Contents\\AutoPlotFlexible.dll"))
  
  (setq dll-candidates (list
    (if cur-dir (strcat cur-dir "/AutoPlotFlexible.dll") nil)
    (if cur-dir (strcat cur-dir "/AutoPlotFlexible_Universal.dll") nil)
    (if cur-dir (strcat cur-dir "/Contents/AutoPlotFlexible.dll") nil)
    (if cur-dir (strcat cur-dir "/bin/AutoPlotFlexible.dll") nil)
    appdata-bundle
    "C:/Users/KIET_PC/Desktop/CAD PRO MAX/Flexible tool/autoplot/bin/AutoPlotFlexible.dll"
    "C:/Users/KIET_PC/Desktop/CAD PRO MAX/in hàng loạt/AutoPlotFlexible.dll"
  ))
  
  (setq target-dll nil)
  (foreach cand dll-candidates
    (if (and (null target-dll) cand (findfile cand))
      (setq target-dll (findfile cand))
    )
  )
  
  (if target-dll
    (progn
      (vl-cmdf "NETLOAD" target-dll)
      (setq doc (vla-get-activedocument (vlax-get-acad-object)))
      (vla-sendcommand doc "AUTOPLOT\n")
      (princ (strcat "\n[AutoPlot Flexible v2.2] Da nap thanh cong: " target-dll))
    )
    (alert "Khong tim thay tap tin AutoPlotFlexible.dll!\nVui long dat AutoPlot.lsp cung thu muc voi AutoPlotFlexible.dll hoac chay Cai_Dat_Tu_Dong.bat.")
  )
  (princ)
)

(defun c:INHANGLOAT () (c:AUTOPLOT))
(defun c:AP () (c:AUTOPLOT))

(princ "\n[AutoPlot Flexible v2.2] Da san sang! Go 'AUTOPLOT' hoac 'AP' de bat dau.\n")
(princ)

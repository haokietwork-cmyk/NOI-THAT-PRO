@echo off
title Cai dat AutoPlot Flexible v2.2.0 cho AutoCAD
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
    echo.
    echo Bam phim bat ky de thoat...
    pause >nul
    exit /b 1
)
echo.
echo Bam phim bat ky de hoan tat...
pause >nul
exit /b 0

@echo off
chcp 65001 >nul
title Cài đặt AutoPlot Flexible cho Autodesk AutoCAD
cls
echo ======================================================================
echo           AUTOPLOT FLEXIBLE - CÀI ĐẶT TỰ ĐỘNG CHO AUTOCAD
echo      In ấn hàng loạt - Nhận diện khổ thực tế - Gộp PDF có Bookmark
echo ======================================================================
echo.

set "TARGET_DIR=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
set "SOURCE_DIR=%~dp0AutoPlotFlexible.bundle"

if not exist "%SOURCE_DIR%" (
    echo [LỖI] Không tìm thấy thư mục AutoPlotFlexible.bundle cùng thư mục với file cài đặt!
    echo Vui lòng đảm bảo bạn đã giải nén toàn bộ thư mục trước khi chạy.
    echo.
    pause
    exit /b 1
)

echo [1/3] Đang tạo thư mục đích trong Autodesk ApplicationPlugins...
if not exist "%APPDATA%\Autodesk\ApplicationPlugins" (
    mkdir "%APPDATA%\Autodesk\ApplicationPlugins"
)

echo [2/3] Đang sao chép AutoPlot Flexible vào hệ thống...
xcopy "%SOURCE_DIR%" "%TARGET_DIR%\" /s /e /i /y /q >nul
if errorlevel 1 (
    echo [LỖI] Sao chép tệp thất bại! Vui lòng đóng AutoCAD nếu đang mở và thử lại.
    echo.
    pause
    exit /b 1
)

echo [3/3] Đang mở khóa (Unblock) các tệp thư viện để Windows không chặn...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%TARGET_DIR%' -Recurse | Unblock-File" >nul 2>&1

echo.
echo ======================================================================
echo                      CÀI ĐẶT HOÀN TẤT THÀNH CÔNG!
echo ======================================================================
echo.
echo Công cụ đã được tích hợp vĩnh viễn vào hệ thống AutoCAD của bạn:
echo   - Tự động nạp khi khởi động AutoCAD (không cần dùng lệnh NETLOAD).
echo   - Tương thích: AutoCAD 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027.
echo.
echo HƯỚNG DẪN SỬ DỤNG NHANH:
echo   1. Mở phần mềm AutoCAD.
echo   2. Quan sát thanh công cụ Ribbon trên cùng: Click vào Tab 'FLEXIBLE TOOL'.
echo   3. Bấm nút lớn 'In Hàng Loạt AutoPlot' (hoặc gõ lệnh AUTOPLOT trên dòng lệnh).
echo   4. Bấm 'Quét tất cả' hoặc 'Window <' để chọn vùng in.
echo   5. Bấm 'IN & GỘP PDF' để in và tự động gộp thành 1 tệp PDF duy nhất có Bookmark!
echo.
echo ======================================================================
echo Bấm phím bất kỳ để đóng cửa sổ này...
pause >nul

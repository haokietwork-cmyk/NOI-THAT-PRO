﻿# ==============================================================================
# AUTOPLOT FLEXIBLE v2.2.0 - BỘ CÀI ĐẶT & NÂNG CẤP TỰ ĐỘNG CHUYÊN NGHIỆP
# Tương thích toàn diện AutoCAD 2014, 2015, 2016, 2017, 2018-2027 (Universal)
# ==============================================================================

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "AutoPlot Flexible v2.2.0 - Cài đặt & Cập nhật tự động"

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "          AUTOPLOT FLEXIBLE v2.2.0 - CÀI ĐẶT & NÂNG CẤP TỰ ĐỘNG       " -ForegroundColor Yellow
Write-Host "     In ấn hàng loạt - Chuẩn tỉ lệ X:1 - Nhận diện Tên & Số hiệu BV   " -ForegroundColor White
Write-Host "     Tương thích: AutoCAD 2014, 2015, 2016, 2017, 2018-2027          " -ForegroundColor Gray
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceBundle = Join-Path $scriptDir "AutoPlotFlexible.bundle"
$targetAppData = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
$targetProgData = Join-Path $env:ProgramData "Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
$expectedVersion = "2.2.0.0"

# 0. Kiểm tra thư mục nguồn
if (-not (Test-Path $sourceBundle)) {
    Write-Host "[LỖI] Không tìm thấy thư mục AutoPlotFlexible.bundle!" -ForegroundColor Red
    Write-Host "Vui lòng giải nén toàn bộ tệp ZIP trước khi chạy cài đặt." -ForegroundColor Yellow
    exit 1
}

# 1. Đóng AutoCAD nếu đang chạy để không bị khóa DLL
Write-Host "[1/5] Kiểm tra tiến trình AutoCAD..." -ForegroundColor Cyan
$acadProcs = Get-Process -Name "acad", "accoreconsole", "acadlt" -ErrorAction SilentlyContinue
if ($acadProcs) {
    Write-Host "[CẢNH BÁO] Phát hiện AutoCAD đang chạy. Đang tự động đóng để giải phóng file..." -ForegroundColor Yellow
    $acadProcs | ForEach-Object {
        try {
            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
        } catch {}
    }
    Start-Sleep -Seconds 2
    # Đợi tối đa 5 giây cho file handle được Windows giải phóng hoàn toàn
    $retry = 0
    while ($retry -lt 5) {
        $remaining = Get-Process -Name "acad", "accoreconsole", "acadlt" -ErrorAction SilentlyContinue
        if (-not $remaining) { break }
        Start-Sleep -Seconds 1
        $retry++
    }
    Write-Host "[OK] Đã giải phóng hoàn toàn tiến trình AutoCAD." -ForegroundColor Green
} else {
    Write-Host "[OK] Không có tiến trình AutoCAD nào đang mở." -ForegroundColor Green
}

# 2. Bảo toàn file giấy phép bản quyền nếu có (.lic)
Write-Host "[2/5] Kiểm tra và sao lưu giấy phép bản quyền..." -ForegroundColor Cyan
$preservedLicPath = $null
$licLocations = @(
    (Join-Path $targetAppData "FlexibleTools.lic"),
    (Join-Path $targetProgData "FlexibleTools.lic")
)
foreach ($loc in $licLocations) {
    if (Test-Path $loc) {
        $tempLic = Join-Path $env:TEMP ("FlexibleTools_lic_backup_" + [System.Guid]::NewGuid().ToString("N") + ".lic")
        Copy-Item -LiteralPath $loc -Destination $tempLic -Force
        $preservedLicPath = $tempLic
        Write-Host "  -> Đã tìm thấy và sao lưu bản quyền của bạn." -ForegroundColor Green
        break
    }
}

# 3. Dọn sạch phiên bản cũ ở cả APPDATA và PROGRAMDATA
Write-Host "[3/5] Dọn dẹp sạch sẽ các phiên bản cũ khỏi hệ thống..." -ForegroundColor Cyan

# Dọn ProgramData nếu có phiên bản cũ tồn đọng
if (Test-Path $targetProgData) {
    try {
        Remove-Item -LiteralPath $targetProgData -Recurse -Force -ErrorAction SilentlyContinue
    } catch {}
}

# Dọn AppData
if (Test-Path $targetAppData) {
    # Thử xóa DLL trước để kiểm tra khóa file
    $oldDll = Join-Path $targetAppData "Contents\AutoPlotFlexible.dll"
    if (Test-Path $oldDll) {
        $deleted = $false
        for ($i = 0; $i -lt 5; $i++) {
            try {
                Remove-Item -LiteralPath $oldDll -Force -ErrorAction Stop
                $deleted = $true
                break
            } catch {
                Start-Sleep -Seconds 1
            }
        }
        if (-not $deleted) {
            Write-Host "[CẢNH BÁO] Tệp AutoPlotFlexible.dll cũ đang bị khóa bởi tiến trình khác!" -ForegroundColor Red
            Write-Host "Vui lòng mở Task Manager và kết thúc tiến trình AutoCAD, hoặc Restart máy tính." -ForegroundColor Yellow
        }
    }
    try {
        Remove-Item -LiteralPath $targetAppData -Recurse -Force -ErrorAction SilentlyContinue
    } catch {}
}

# Tạo thư mục cha nếu chưa có
$pluginsDir = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins"
if (-not (Test-Path $pluginsDir)) {
    New-Item -ItemType Directory -Path $pluginsDir -Force | Out-Null
}

# 4. Sao chép phiên bản mới nhất 2.2.0
Write-Host "[4/5] Đang sao chép AutoPlot Flexible v2.2.0 vào hệ thống..." -ForegroundColor Cyan
Copy-Item -LiteralPath $sourceBundle -Destination $targetAppData -Recurse -Force

# Khôi phục file bản quyền nếu đã có
if ($preservedLicPath -and (Test-Path $preservedLicPath)) {
    Copy-Item -LiteralPath $preservedLicPath -Destination (Join-Path $targetAppData "FlexibleTools.lic") -Force
    Remove-Item -LiteralPath $preservedLicPath -Force -ErrorAction SilentlyContinue
    Write-Host "  -> Đã tự động khôi phục giấy phép bản quyền của bạn!" -ForegroundColor Green
}

# Mở khóa Unblock tất cả các file
Get-ChildItem -LiteralPath $targetAppData -Recurse | Unblock-File -ErrorAction SilentlyContinue

# 5. Xác minh nghiêm ngặt phiên bản đã cài đặt
Write-Host "[5/5] Xác thực tính toàn vẹn và phiên bản sau cài đặt..." -ForegroundColor Cyan
$installedDll = Join-Path $targetAppData "Contents\AutoPlotFlexible.dll"

if (-not (Test-Path $installedDll)) {
    Write-Host ""
    Write-Host "======================================================================" -ForegroundColor Red
    Write-Host "                 [LỖI] CÀI ĐẶT THẤT BẠI                               " -ForegroundColor Red
    Write-Host "Không tìm thấy AutoPlotFlexible.dll sau khi sao chép!                  " -ForegroundColor Red
    Write-Host "Vui lòng tắt phần mềm diệt virus hoặc kiểm tra quyền Administrator.    " -ForegroundColor Yellow
    Write-Host "======================================================================" -ForegroundColor Red
    exit 1
}

$fileVer = (Get-Item -LiteralPath $installedDll).VersionInfo.FileVersion
$prodVer = (Get-Item -LiteralPath $installedDll).VersionInfo.ProductVersion
$fileLen = (Get-Item -LiteralPath $installedDll).Length

if ($fileVer -ne $expectedVersion) {
    Write-Host ""
    Write-Host "======================================================================" -ForegroundColor Red
    Write-Host "              [CẢNH BÁO] CẬP NHẬT CHƯA HOÀN TẤT TRIỆT ĐỂ              " -ForegroundColor Red
    Write-Host "Phiên bản trong máy hiện tại: $fileVer (Yêu cầu: $expectedVersion)    " -ForegroundColor Red
    Write-Host "File DLL cũ chưa được ghi đè do đang bị hệ điều hành khóa.            " -ForegroundColor Yellow
    Write-Host ""
    Write-Host "HƯỚNG DẪN XỬ LÝ:" -ForegroundColor White
    Write-Host "  1. Khởi động lại máy tính (Restart Windows)." -ForegroundColor White
    Write-Host "  2. Chạy lại file cài đặt này ngay khi máy tính vừa mở lên." -ForegroundColor White
    Write-Host "======================================================================" -ForegroundColor Red
    exit 1
}

# THÀNH CÔNG RỰC RỠ VÀ MINH BẠCH
Write-Host ""
Write-Host "======================================================================" -ForegroundColor Green
Write-Host "                 CÀI ĐẶT & XÁC THỰC HOÀN TẤT 100%!                    " -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Green
Write-Host "  [OK] Phiên bản:         $fileVer (Chuẩn Universal 2014-2027)" -ForegroundColor White
Write-Host "  [OK] Động cơ PDF:       PdfSharp gộp file có Bookmark sẵn sàng" -ForegroundColor White
Write-Host "  [OK] Xem trước:         Hỗ trợ 'Kiểm tra trước khi lưu' trực quan" -ForegroundColor White
Write-Host "  [OK] Nhận diện khung:   Chuẩn tỉ lệ X:1 (11:1, 8:1, 6:1...) & Tên BV" -ForegroundColor White
Write-Host "  [OK] Vị trí cài đặt:    $targetAppData" -ForegroundColor Gray
Write-Host "======================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "HƯỚNG DẪN MỞ CÔNG CỤ TRONG AUTOCAD:" -ForegroundColor Cyan
Write-Host "  1. Khởi động phần mềm AutoCAD." -ForegroundColor White
Write-Host "  2. Gõ lệnh: AUTOPLOT (hoặc phím tắt: AP)." -ForegroundColor White
Write-Host "  3. Hoặc bấm vào Tab 'FLEXIBLE TOOL' trên thanh Ribbon." -ForegroundColor White
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""
exit 0

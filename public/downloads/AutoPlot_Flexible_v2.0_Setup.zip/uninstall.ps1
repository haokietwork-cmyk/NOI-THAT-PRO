﻿# ==============================================================================
# AUTOPLOT FLEXIBLE - GỠ CÀI ĐẶT SẠCH SẼ KHỎI AUTOCAD
# ==============================================================================

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "Gỡ cài đặt AutoPlot Flexible"

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "                GỠ CÀI ĐẶT AUTOPLOT FLEXIBLE KHỎI HỆ THỐNG             " -ForegroundColor Yellow
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

$targetAppData = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
$targetProgData = Join-Path $env:ProgramData "Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"

if ((-not (Test-Path $targetAppData)) -and (-not (Test-Path $targetProgData))) {
    Write-Host "[THÔNG BÁO] AutoPlot Flexible không được cài đặt trên hệ thống này." -ForegroundColor Gray
    exit 0
}

# Đóng AutoCAD nếu mở
$acadProcs = Get-Process -Name "acad", "accoreconsole", "acadlt" -ErrorAction SilentlyContinue
if ($acadProcs) {
    Write-Host "[CẢNH BÁO] Đang đóng AutoCAD để giải phóng tệp..." -ForegroundColor Yellow
    $acadProcs | ForEach-Object {
        try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
    }
    Start-Sleep -Seconds 2
}

Write-Host "Đang gỡ bỏ AutoPlot Flexible..." -ForegroundColor Cyan
if (Test-Path $targetAppData) {
    Remove-Item -LiteralPath $targetAppData -Recurse -Force -ErrorAction SilentlyContinue
}
if (Test-Path $targetProgData) {
    Remove-Item -LiteralPath $targetProgData -Recurse -Force -ErrorAction SilentlyContinue
}

if (Test-Path $targetAppData) {
    Write-Host "[LỖI] Không thể xóa một số tệp trong AppData. Vui lòng restart máy rồi thử lại." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Green
Write-Host "                      GỠ CÀI ĐẶT THÀNH CÔNG!                          " -ForegroundColor Green
Write-Host "AutoPlot Flexible đã được gỡ bỏ hoàn toàn khỏi AutoCAD.               " -ForegroundColor White
Write-Host "======================================================================" -ForegroundColor Green
Write-Host ""
exit 0

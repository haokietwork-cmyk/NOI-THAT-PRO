@echo off
title Go cai dat AutoPlot Flexible cho AutoCAD
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
if errorlevel 1 (
    echo.
    echo Bam phim bat ky de thoat...
    pause >nul
    exit /b 1
)
echo.
echo Bam phim bat ky de hoan tat...
pause >nul
exit /b 0

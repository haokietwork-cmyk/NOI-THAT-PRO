@echo off
chcp 65001 >nul
title Gỡ cài đặt AutoPlot Flexible cho Autodesk AutoCAD
cls
echo ======================================================================
echo                GỠ CÀI ĐẶT AUTOPLOT FLEXIBLE KHỎI AUTOCAD
echo ======================================================================
echo.

set "TARGET_DIR=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"

if not exist "%TARGET_DIR%" (
    echo [THÔNG BÁO] AutoPlot Flexible hiện không được cài đặt trong thư mục:
    echo %TARGET_DIR%
    echo.
    pause
    exit /b 0
)

echo Bạn có chắc chắn muốn gỡ cài đặt AutoPlot Flexible?
set /p "CHOICE=Nhập Y để đồng ý gỡ, hoặc bấm phím bất kỳ để hủy [Y/N]: "
if /i not "%CHOICE%"=="Y" (
    echo.
    echo Đã hủy thao tác gỡ cài đặt.
    pause
    exit /b 0
)

echo.
echo Đang gỡ bỏ AutoPlot Flexible khỏi hệ thống...
rmdir /s /q "%TARGET_DIR%" 2>nul
if exist "%TARGET_DIR%" (
    echo [LỖI] Không thể xóa toàn bộ tệp! Có thể AutoCAD đang chạy và giữ khóa tệp DLL.
    echo Vui lòng đóng tất cả cửa sổ AutoCAD và chạy lại file này.
    echo.
    pause
    exit /b 1
)

echo.
echo ======================================================================
echo                      GỠ CÀI ĐẶT HOÀN TẤT!
echo AutoPlot Flexible đã được gỡ bỏ sạch sẽ khỏi hệ thống AutoCAD của bạn.
echo ======================================================================
echo.
pause

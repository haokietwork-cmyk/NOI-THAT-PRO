@echo off
chcp 65001 >nul
title Gỡ cài đặt AutoPlot Flexible cho Autodesk AutoCAD
cls
echo ======================================================================
echo                GỠ CÀI ĐẶT AUTOPLOT FLEXIBLE KHỎI AUTOCAD
echo ======================================================================
echo.

set "TARGET_USER=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
set "TARGET_ALL=%ProgramData%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"

echo Bạn có chắc chắn muốn gỡ cài đặt AutoPlot Flexible khỏi hệ thống?
set /p "CHOICE=Nhập Y để đồng ý gỡ, hoặc phím bất kỳ để hủy [Y/N]: "
if /i not "%CHOICE%"=="Y" (
    echo.
    echo Đã hủy thao tác gỡ cài đặt.
    pause
    exit /b 0
)

echo.
tasklist /fi "imagename eq acad.exe" 2>nul | find /i "acad.exe" >nul
if not errorlevel 1 (
    echo [CẢNH BÁO] AutoCAD đang chạy! Đang tự động đóng để không bị khóa file...
    taskkill /f /im acad.exe >nul 2>&1
    taskkill /f /im acadlt.exe >nul 2>&1
    taskkill /f /im accoreconsole.exe >nul 2>&1
    timeout /t 3 /nobreak >nul
)

echo Đang gỡ bỏ AutoPlot Flexible khỏi hệ thống...
if exist "%TARGET_USER%" rmdir /s /q "%TARGET_USER%" 2>nul
if exist "%TARGET_ALL%" rmdir /s /q "%TARGET_ALL%" 2>nul
if exist "%APPDATA%\Autodesk\ApplicationPlugins\APMP.bundle" rmdir /s /q "%APPDATA%\Autodesk\ApplicationPlugins\APMP.bundle" 2>nul
if exist "%ProgramData%\Autodesk\ApplicationPlugins\APMP.bundle" rmdir /s /q "%ProgramData%\Autodesk\ApplicationPlugins\APMP.bundle" 2>nul

echo.
echo ======================================================================
echo                      GỠ CÀI ĐẶT HOÀN TẤT!
echo AutoPlot Flexible đã được gỡ bỏ sạch sẽ khỏi hệ thống AutoCAD của bạn.
echo ======================================================================
echo.
pause

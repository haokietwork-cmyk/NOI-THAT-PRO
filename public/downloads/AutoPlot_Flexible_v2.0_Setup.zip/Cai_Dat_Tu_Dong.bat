﻿@echo off
chcp 65001 >nul
echo ========================================================
echo   CÀI ĐẶT BỘ CÔNG CỤ AUTOPLOT FLEXIBLE v2.1 (.NET)
echo ========================================================
set "TARGET_DIR=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle"
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
xcopy /E /Y /I "%~dp0AutoPlotFlexible.bundle" "%TARGET_DIR%"
echo.
echo [OK] Đã cài đặt thành công AutoPlot Flexible v2.1!
echo Khởi động AutoCAD và gõ lệnh AUTOPLOT hoặc AUTOPLOT_PALETTE để sử dụng.
pause
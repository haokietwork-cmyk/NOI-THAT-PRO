@echo off
echo ========================================================
echo    DANG CAI DAT FLEXIBLE TOOL SUITE CHO AUTOCAD
echo ========================================================
set DEST=%APPDATA%\Autodesk\ApplicationPlugins\AutoPlotFlexible.bundle
if not exist "%DEST%" mkdir "%DEST%"
xcopy /E /Y /I "%~dp0AutoPlotFlexible.bundle\*" "%DEST%\"
echo.
echo Cai dat hoan tat! Vui long mo AutoCAD va go AUTOPLOT de su dung.
pause
